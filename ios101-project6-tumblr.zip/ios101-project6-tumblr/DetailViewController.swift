//
//  DetailViewController.swift
//  ios101-project6-tumblr
//
//  Created by Marcus Ezell on 10/27/25.
//

import UIKit

class DetailViewController: UIViewController {
    
    var post: Post!
    
    @IBOutlet weak var imgView: UIImageView! //Imageview
    
    @IBOutlet weak var backButton: UINavigationItem!
    
    @IBOutlet weak var capTextView: UITextView! //Textview
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
